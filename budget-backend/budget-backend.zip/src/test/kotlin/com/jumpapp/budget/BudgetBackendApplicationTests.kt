package com.jumpapp.budget

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BudgetBackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}
